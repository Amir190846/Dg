export const siteData = {
  name: "المطعم الفاخر",
  tagline: "حيث تلتقي الأصالة بالفخامة",
  description: "نقدم لك تجربة تذوق لا تُنسى في أجواء كلاسيكية هادئة، مع أطباق محضرة بعناية من أجود المكونات الطازجة. جميع أطباقنا تعكس تراثنا العريق.",
  contact: {
    address: "العنوان الدقيق سيتم إضافته هنا",
    phone: "+964 000 000 0000",
    whatsapp: "+964 000 000 0000",
    email: "info@restaurant.com",
    hours: "يومياً: 1:00 مساءً - 11:30 مساءً"
  },
  social: {
    instagram: "#",
    facebook: "#"
  }
};

export const menuCategories = ["المقبلات", "الأطباق الرئيسية", "المشويات", "الحلويات", "المشروبات"];

export const menuItems = [
  {
    id: 1,
    name: "حمص بالكمأة",
    nameEn: "Truffle Hummus",
    description: "حمص ناعم مع زيت الكمأة الفاخر والصنوبر المحمص.",
    price: 8000,
    category: "المقبلات",
    image: "https://images.unsplash.com/photo-1577906096429-f73c2c312435?q=80&w=800&auto=format&fit=crop",
    isFeatured: false
  },
  {
    id: 2,
    name: "كباب عراقي ملكي",
    nameEn: "Royal Iraqi Kebab",
    description: "سيخ كباب لحم غنم طازج متبل بخلطتنا السرية، يقدم مع الخضار المشوية.",
    price: 22000,
    category: "المشويات",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=800&auto=format&fit=crop",
    isFeatured: true
  },
  {
    id: 3,
    name: "موزات لحم بالزعفران",
    nameEn: "Saffron Lamb Shanks",
    description: "موزات لحم مطهوة ببطء مع أرز الزعفران والمكسرات المحمصة.",
    price: 28000,
    category: "الأطباق الرئيسية",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop",
    isFeatured: true
  },
  {
    id: 4,
    name: "كنافة الفستق",
    nameEn: "Pistachio Kunafa",
    description: "كنافة ذهبية محشوة بالقشطة الطازجة ومغطاة بالفستق الحلبي.",
    price: 10000,
    category: "الحلويات",
    image: "https://images.unsplash.com/photo-1551024506-0cb4a1692231?q=80&w=800&auto=format&fit=crop",
    isFeatured: false
  }
];